# LIFECARE 2.0
Updated Android starter project: premium teal/mint dashboard, weekday exercise and meal cards, monthly North India seasonal food suggestions, configurable alternating 15-day day/night shift cycle, local reminder scheduling, and a basic weight log. Offline-first; designed for Android 11 and low-memory phones.

Build with Android Gradle Plugin 8.7.3, Java 17, Gradle 8.9, compile SDK 35.
